﻿namespace POS_Project
{
    partial class SupplierModule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SupplierModule));
            this.Supplier_Emial_TextBox = new System.Windows.Forms.TextBox();
            this.Supplier_Email = new System.Windows.Forms.Label();
            this.Supplier_PhoneNum = new System.Windows.Forms.Label();
            this.Supplier_ContactPerson = new System.Windows.Forms.Label();
            this.Supplier_Address_textBox1 = new System.Windows.Forms.TextBox();
            this.Supplier_address = new System.Windows.Forms.Label();
            this.id_label = new System.Windows.Forms.Label();
            this.Products_cancel_btn = new System.Windows.Forms.Button();
            this.Supplier_update_btn = new System.Windows.Forms.Button();
            this.Supplier_save_btn = new System.Windows.Forms.Button();
            this.Suppier_name_textBox1 = new System.Windows.Forms.TextBox();
            this.Supplier_Name = new System.Windows.Forms.Label();
            this.Products_pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Products_mod_label = new System.Windows.Forms.Label();
            this.Brand_mod_header = new System.Windows.Forms.Panel();
            this.Supplier_ContactPersonTextBox = new System.Windows.Forms.TextBox();
            this.Supplier_Phone_Number_Textbox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Products_pictureBox1)).BeginInit();
            this.Brand_mod_header.SuspendLayout();
            this.SuspendLayout();
            // 
            // Supplier_Emial_TextBox
            // 
            this.Supplier_Emial_TextBox.BackColor = System.Drawing.Color.LightGray;
            this.Supplier_Emial_TextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Supplier_Emial_TextBox.Location = new System.Drawing.Point(177, 314);
            this.Supplier_Emial_TextBox.Name = "Supplier_Emial_TextBox";
            this.Supplier_Emial_TextBox.Size = new System.Drawing.Size(435, 20);
            this.Supplier_Emial_TextBox.TabIndex = 42;
            // 
            // Supplier_Email
            // 
            this.Supplier_Email.AutoSize = true;
            this.Supplier_Email.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Supplier_Email.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Supplier_Email.Location = new System.Drawing.Point(46, 314);
            this.Supplier_Email.Name = "Supplier_Email";
            this.Supplier_Email.Size = new System.Drawing.Size(52, 18);
            this.Supplier_Email.TabIndex = 41;
            this.Supplier_Email.Text = "Email:";
            // 
            // Supplier_PhoneNum
            // 
            this.Supplier_PhoneNum.AutoSize = true;
            this.Supplier_PhoneNum.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Supplier_PhoneNum.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Supplier_PhoneNum.Location = new System.Drawing.Point(40, 254);
            this.Supplier_PhoneNum.Name = "Supplier_PhoneNum";
            this.Supplier_PhoneNum.Size = new System.Drawing.Size(121, 18);
            this.Supplier_PhoneNum.TabIndex = 39;
            this.Supplier_PhoneNum.Text = "Phone Number:";
            // 
            // Supplier_ContactPerson
            // 
            this.Supplier_ContactPerson.AutoSize = true;
            this.Supplier_ContactPerson.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Supplier_ContactPerson.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Supplier_ContactPerson.Location = new System.Drawing.Point(40, 190);
            this.Supplier_ContactPerson.Name = "Supplier_ContactPerson";
            this.Supplier_ContactPerson.Size = new System.Drawing.Size(123, 18);
            this.Supplier_ContactPerson.TabIndex = 38;
            this.Supplier_ContactPerson.Text = "Contact Person:";
            // 
            // Supplier_Address_textBox1
            // 
            this.Supplier_Address_textBox1.BackColor = System.Drawing.Color.LightGray;
            this.Supplier_Address_textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Supplier_Address_textBox1.Location = new System.Drawing.Point(177, 127);
            this.Supplier_Address_textBox1.Name = "Supplier_Address_textBox1";
            this.Supplier_Address_textBox1.Size = new System.Drawing.Size(435, 20);
            this.Supplier_Address_textBox1.TabIndex = 36;
            // 
            // Supplier_address
            // 
            this.Supplier_address.AutoSize = true;
            this.Supplier_address.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Supplier_address.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Supplier_address.Location = new System.Drawing.Point(40, 128);
            this.Supplier_address.Name = "Supplier_address";
            this.Supplier_address.Size = new System.Drawing.Size(70, 18);
            this.Supplier_address.TabIndex = 35;
            this.Supplier_address.Text = "Address:";
            // 
            // id_label
            // 
            this.id_label.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.id_label.AutoSize = true;
            this.id_label.Location = new System.Drawing.Point(45, 364);
            this.id_label.Name = "id_label";
            this.id_label.Size = new System.Drawing.Size(18, 13);
            this.id_label.TabIndex = 32;
            this.id_label.Text = "ID";
            this.id_label.Visible = false;
            // 
            // Products_cancel_btn
            // 
            this.Products_cancel_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Products_cancel_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Products_cancel_btn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Products_cancel_btn.Location = new System.Drawing.Point(533, 362);
            this.Products_cancel_btn.Name = "Products_cancel_btn";
            this.Products_cancel_btn.Size = new System.Drawing.Size(79, 31);
            this.Products_cancel_btn.TabIndex = 31;
            this.Products_cancel_btn.Text = "Cancel";
            this.Products_cancel_btn.UseVisualStyleBackColor = false;
            this.Products_cancel_btn.Click += new System.EventHandler(this.Products_cancel_btn_Click);
            // 
            // Supplier_update_btn
            // 
            this.Supplier_update_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Supplier_update_btn.BackColor = System.Drawing.Color.Olive;
            this.Supplier_update_btn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Supplier_update_btn.Location = new System.Drawing.Point(447, 362);
            this.Supplier_update_btn.Name = "Supplier_update_btn";
            this.Supplier_update_btn.Size = new System.Drawing.Size(79, 31);
            this.Supplier_update_btn.TabIndex = 30;
            this.Supplier_update_btn.Text = "Update";
            this.Supplier_update_btn.UseVisualStyleBackColor = false;
            this.Supplier_update_btn.Click += new System.EventHandler(this.Supplier_update_btn_Click);
            // 
            // Supplier_save_btn
            // 
            this.Supplier_save_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Supplier_save_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(42)))), ((int)(((byte)(68)))));
            this.Supplier_save_btn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Supplier_save_btn.Location = new System.Drawing.Point(359, 362);
            this.Supplier_save_btn.Name = "Supplier_save_btn";
            this.Supplier_save_btn.Size = new System.Drawing.Size(79, 31);
            this.Supplier_save_btn.TabIndex = 29;
            this.Supplier_save_btn.Text = "Save";
            this.Supplier_save_btn.UseVisualStyleBackColor = false;
            this.Supplier_save_btn.Click += new System.EventHandler(this.Supplier_save_btn_Click);
            // 
            // Suppier_name_textBox1
            // 
            this.Suppier_name_textBox1.BackColor = System.Drawing.Color.LightGray;
            this.Suppier_name_textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Suppier_name_textBox1.Location = new System.Drawing.Point(177, 72);
            this.Suppier_name_textBox1.Name = "Suppier_name_textBox1";
            this.Suppier_name_textBox1.Size = new System.Drawing.Size(435, 20);
            this.Suppier_name_textBox1.TabIndex = 28;
            // 
            // Supplier_Name
            // 
            this.Supplier_Name.AutoSize = true;
            this.Supplier_Name.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Supplier_Name.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Supplier_Name.Location = new System.Drawing.Point(40, 72);
            this.Supplier_Name.Name = "Supplier_Name";
            this.Supplier_Name.Size = new System.Drawing.Size(121, 18);
            this.Supplier_Name.TabIndex = 27;
            this.Supplier_Name.Text = "Supplier Name:";
            // 
            // Products_pictureBox1
            // 
            this.Products_pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Products_pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Products_pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("Products_pictureBox1.Image")));
            this.Products_pictureBox1.Location = new System.Drawing.Point(590, 6);
            this.Products_pictureBox1.Name = "Products_pictureBox1";
            this.Products_pictureBox1.Size = new System.Drawing.Size(31, 28);
            this.Products_pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Products_pictureBox1.TabIndex = 1;
            this.Products_pictureBox1.TabStop = false;
            this.Products_pictureBox1.Click += new System.EventHandler(this.Products_pictureBox1_Click);
            // 
            // Products_mod_label
            // 
            this.Products_mod_label.AutoSize = true;
            this.Products_mod_label.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Products_mod_label.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Products_mod_label.Location = new System.Drawing.Point(12, 9);
            this.Products_mod_label.Name = "Products_mod_label";
            this.Products_mod_label.Size = new System.Drawing.Size(131, 18);
            this.Products_mod_label.TabIndex = 0;
            this.Products_mod_label.Text = "Products Module";
            // 
            // Brand_mod_header
            // 
            this.Brand_mod_header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(42)))), ((int)(((byte)(68)))));
            this.Brand_mod_header.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Brand_mod_header.Controls.Add(this.Products_pictureBox1);
            this.Brand_mod_header.Controls.Add(this.Products_mod_label);
            this.Brand_mod_header.Dock = System.Windows.Forms.DockStyle.Top;
            this.Brand_mod_header.Location = new System.Drawing.Point(0, 0);
            this.Brand_mod_header.Name = "Brand_mod_header";
            this.Brand_mod_header.Size = new System.Drawing.Size(633, 41);
            this.Brand_mod_header.TabIndex = 26;
            // 
            // Supplier_ContactPersonTextBox
            // 
            this.Supplier_ContactPersonTextBox.BackColor = System.Drawing.Color.LightGray;
            this.Supplier_ContactPersonTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Supplier_ContactPersonTextBox.Location = new System.Drawing.Point(177, 190);
            this.Supplier_ContactPersonTextBox.Name = "Supplier_ContactPersonTextBox";
            this.Supplier_ContactPersonTextBox.Size = new System.Drawing.Size(435, 20);
            this.Supplier_ContactPersonTextBox.TabIndex = 45;
            // 
            // Supplier_Phone_Number_Textbox
            // 
            this.Supplier_Phone_Number_Textbox.BackColor = System.Drawing.Color.LightGray;
            this.Supplier_Phone_Number_Textbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Supplier_Phone_Number_Textbox.Location = new System.Drawing.Point(177, 254);
            this.Supplier_Phone_Number_Textbox.Name = "Supplier_Phone_Number_Textbox";
            this.Supplier_Phone_Number_Textbox.Size = new System.Drawing.Size(435, 20);
            this.Supplier_Phone_Number_Textbox.TabIndex = 46;
            // 
            // SupplierModule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(633, 404);
            this.ControlBox = false;
            this.Controls.Add(this.Supplier_Phone_Number_Textbox);
            this.Controls.Add(this.Supplier_ContactPersonTextBox);
            this.Controls.Add(this.Supplier_Emial_TextBox);
            this.Controls.Add(this.Supplier_Email);
            this.Controls.Add(this.Supplier_PhoneNum);
            this.Controls.Add(this.Supplier_ContactPerson);
            this.Controls.Add(this.Supplier_Address_textBox1);
            this.Controls.Add(this.Supplier_address);
            this.Controls.Add(this.id_label);
            this.Controls.Add(this.Products_cancel_btn);
            this.Controls.Add(this.Supplier_update_btn);
            this.Controls.Add(this.Supplier_save_btn);
            this.Controls.Add(this.Suppier_name_textBox1);
            this.Controls.Add(this.Supplier_Name);
            this.Controls.Add(this.Brand_mod_header);
            this.Name = "SupplierModule";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SupplierModule";
            ((System.ComponentModel.ISupportInitialize)(this.Products_pictureBox1)).EndInit();
            this.Brand_mod_header.ResumeLayout(false);
            this.Brand_mod_header.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.TextBox Supplier_Emial_TextBox;
        private System.Windows.Forms.Label Supplier_Email;
        private System.Windows.Forms.Label Supplier_PhoneNum;
        private System.Windows.Forms.Label Supplier_ContactPerson;
        public System.Windows.Forms.TextBox Supplier_Address_textBox1;
        private System.Windows.Forms.Label Supplier_address;
        public System.Windows.Forms.Label id_label;
        public System.Windows.Forms.Button Products_cancel_btn;
        public System.Windows.Forms.Button Supplier_update_btn;
        public System.Windows.Forms.Button Supplier_save_btn;
        public System.Windows.Forms.TextBox Suppier_name_textBox1;
        private System.Windows.Forms.Label Supplier_Name;
        private System.Windows.Forms.PictureBox Products_pictureBox1;
        private System.Windows.Forms.Label Products_mod_label;
        private System.Windows.Forms.Panel Brand_mod_header;
        public System.Windows.Forms.TextBox Supplier_ContactPersonTextBox;
        public System.Windows.Forms.TextBox Supplier_Phone_Number_Textbox;
    }
}